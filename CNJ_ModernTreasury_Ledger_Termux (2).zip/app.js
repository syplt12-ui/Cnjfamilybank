require('dotenv').config();
const axios = require('axios');

// Load environment variables
const { MODERN_TREASURY_API_KEY, ORG_ID, CNJ_LEDGER_ID, CNJ_CURRENCY } = process.env;

// Initialize Modern Treasury client
const modernTreasury = axios.create({
  baseURL: 'https://api.moderntreasury.com/api',
  headers: {
    Authorization: `Bearer ${MODERN_TREASURY_API_KEY}`,
    'Modern-Treasury-Organization-Id': ORG_ID,
  },
});

// CNJDUCKETS Ledger mock example
const ledgerEntry = {
  ledger_id: CNJ_LEDGER_ID,
  currency: CNJ_CURRENCY,
  amount: 1000,
  memo: 'Trust disbursement from SEIANYOUNGBLOOD PRIVATE TRUST',
  metadata: {
    trustee: 'Jennifer Garcia',
    grantor: 'Seian Youngblood',
    reference: 'SY-0002',
    payout_channel: 'Modern Treasury'
  }
};

// Send ledger transaction to Modern Treasury
(async () => {
  try {
    console.log('🟢 Connecting to Modern Treasury...');
    const response = await modernTreasury.post('/ledger_entries', ledgerEntry);
    console.log('✅ Ledger entry created:', response.data);
  } catch (err) {
    console.error('❌ Error creating ledger entry:', err.response?.data || err.message);
  }
})();
