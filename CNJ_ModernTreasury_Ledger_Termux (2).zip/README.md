# CNJDUCKETS × Modern Treasury Ledger Integration

This Node.js app connects the **SEIANYOUNGBLOOD PRIVATE TRUST** CNJDUCKETS ledger to **Modern Treasury**.

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```

2. Add your credentials in `.env`:
   ```bash
   MODERN_TREASURY_API_KEY=your-real-api-key
   ORG_ID=your-organization-id
   CNJ_LEDGER_ID=cnj-ledger-2473
   CNJ_CURRENCY=CNJDUCKETS
   ```

3. Run the app:
   ```bash
   npm start
   ```

---

**Author:** Seian Youngblood  
**Trust:** SEIANYOUNGBLOOD PRIVATE TRUST  
**Agent:** Jennifer Garcia
