#!/data/data/com.termux/files/usr/bin/bash

# Termux Node.js check
if ! command -v node &> /dev/null; then
  echo "Node.js not found. Installing..."
  pkg install -y nodejs
fi

if ! command -v npm &> /dev/null; then
  echo "npm not found. Installing..."
  pkg install -y npm
fi

echo "✅ Node.js and npm are installed"

# Install dependencies
echo "Installing project dependencies..."
npm install

# Run the app
echo "Running CNJ Modern Treasury Ledger..."
npm start
